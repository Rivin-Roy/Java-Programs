// 1. Write a program to print a message

public class q1 {
    public static void main(String args[]) {
        System.out.println("Hello World");
    }
}
